// app.js

// Form validation for the contact section
document.addEventListener('DOMContentLoaded', function () {
    const contactForm = document.getElementById('contact-form');

    contactForm.addEventListener('submit', function (event) {
        event.preventDefault();

        // Validate form fields
        const nameInput = document.getElementById('name');
        const emailInput = document.getElementById('email');
        const messageInput = document.getElementById('message');

        if (validateField(nameInput) && validateField(emailInput) && validateField(messageInput)) {
            // Form submission logic (You can customize this part)
            alert('Form submitted successfully!');
            contactForm.reset();
        }
    });

    function validateField(field) {
        if (field.value.trim() === '') {
            alert(`Please enter your ${field.name}.`);
            return false;
        }

        return true;
    }
});
